#include <QCoreApplication>
#include <QDataStream>
#include <QDebug>
#include <QFile>
#include "message.h"
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // Writing to file
    QDataStream io;
    QFile arch;
    // Replace the path below before running on your machine
    arch.setFileName("/Users/Mr.Pandya/Desktop/object");
    arch.open(QIODevice::WriteOnly);
    io.setDevice(&arch);
    Message message =  Message();
    message.setMessageType(MessageType::GetRoomDetails);
    message.insertDataString("Vivek");
    message.insertDataString("Pandya");
    message.insertDataString("Qt");

    Peer peer  = Peer();
    peer.setNickName("Batman");
    peer.setPeerAddress(QHostAddress::AnyIPv4);

    message.insertPeerObj(peer);

    Room room = Room();
    room.setPort(12000);
    room.setRoomName("Qt-Developers");
    room.setRoomDesc("Qt developer's discussion room");

    room.addNickName(peer);

    message.insertRoomObj(room);


    io << message;

    arch.flush();
    arch.close();

    // Read from the file
    arch.open(QIODevice::ReadOnly);
    Message readMessage = Message();

    io >> readMessage;

    qDebug() << (int)readMessage.getMessageType();
    for(QString dataString: readMessage.getDataStrings())
        qDebug() << dataString << "\n";
    for(Peer peer : readMessage.getPeerVector())
        qDebug() << peer.getpeerAddress() << "\n" << peer.getNickName() << "\n";


    return a.exec();
}
